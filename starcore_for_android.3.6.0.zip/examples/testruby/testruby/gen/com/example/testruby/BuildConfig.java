/** Automatically generated file. DO NOT MODIFY */
package com.example.testruby;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}